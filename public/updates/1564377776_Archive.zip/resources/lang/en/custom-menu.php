<?php return array (
  'nav-menu' => 
  array (
    'blog' => 'Blog',
    'courses' => 'Courses',
    'bundles' => 'Bundles',
    'forums' => 'Forums',
    'contact' => 'Contact',
    'about-us' => 'About Us',
  ),
  'dummy' => 
  array (
  ),
);