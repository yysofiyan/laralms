<?php

return array (
  'nav-menu' => 
  array (
    'about-us' => 'À propos de nous',
    'blog' => 'Blog',
    'bundles' => 'Liasses',
    'contact' => 'Contact',
    'courses' => 'Cours',
    'forums' => 'Les forums',
  ),
);
