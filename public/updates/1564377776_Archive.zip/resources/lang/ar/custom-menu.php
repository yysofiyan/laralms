<?php

return array (
  'nav-menu' => 
  array (
    'about-us' => 'معلومات عنا',
    'blog' => 'مدونة',
    'bundles' => 'بال',
    'contact' => 'اتصل',
    'courses' => 'الدورات',
    'forums' => 'المنتديات',
  ),
);
