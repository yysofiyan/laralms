<?php

return array (
  'nav-menu' => 
  array (
    'about-us' => 'Sobre nosotros',
    'blog' => 'Blog',
    'bundles' => 'manojos',
    'contact' => 'Contacto',
    'courses' => 'Los cursos',
    'forums' => 'La',
  ),
);
